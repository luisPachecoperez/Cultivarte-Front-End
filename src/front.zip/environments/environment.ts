export const environment = {
  production: false,
  COOKIE_EXP_MINUTES: 40,
  COOKIE_SECRET:
    'rjXfP4XbWDWArb4THdLBunmvBUafNdQWnRkdEdmQPGLJvQTEtMhr8DuPmZ9MX23x',
  USER_COOKIE_NAME: 'session_auth',
};
