export interface GraphQLResponse {
  exitoso: string | null;
  mensaje: string | null;
}
