export interface CookieInterface {
  token: string;
  access_token: string;
  jwt: string;
}
