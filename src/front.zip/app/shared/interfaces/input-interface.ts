export interface Input<T> {
  getValue(): T;
}
