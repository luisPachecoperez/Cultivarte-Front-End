export interface Parametros_generalesDB {
  id_parametro_general: string;
  nombre_parametro: string;
  descripcion: string;
  estado: any;
  id_creado_por: string;
  fecha_creacion: Date;
  id_modificado_por: string;
  fecha_modificacion: Date;
  syncStatus: string;
}
