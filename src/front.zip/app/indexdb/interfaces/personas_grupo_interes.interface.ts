export interface Personas_grupo_interesDB {
  id_personas_grupo_interes: string;
  id_persona: string;
  id_grupo_interes: string;
  id_creado_por: string;
  fecha_creacion: Date;
  id_modificado_por: string;
  fecha_modificacion: Date;
  syncStatus: string;
}
