export interface Personas_programasDB {
  id_persona_programa: string;
  id_persona: string;
  id_programa: string;
  id_creado_por: string;
  fecha_creacion: Date;
  id_modificado_por: string;
  fecha_modificacion: Date;
  syncStatus: string;
}
