export interface PoblacionesDB {
  id_poblacion: string;
  id_padre: string;
  nombre: string;
  syncStatus: string;
}
