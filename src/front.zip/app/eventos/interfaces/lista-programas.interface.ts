export interface Programas {
  id_programa: string | null;
  nombre: string | null;
}
