export interface Responsables {
  id_responsable: string | null;
  nombre: string | null;
}
