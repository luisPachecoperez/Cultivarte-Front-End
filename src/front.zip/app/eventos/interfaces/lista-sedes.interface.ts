export interface Sedes {
  id_sede: string;
  nombre: string;
}
