export interface Beneficiarios {
  id_persona: string;
  nombre_completo: string;
  id_sede: string;
  identificacion: string;
}
