export interface Aliados {
  id_aliado: string;
  nombre: string;
}
