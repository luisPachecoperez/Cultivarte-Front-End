export interface Frecuencias {
  id_frecuencia: string | null;
  nombre: string | null;
}
