export interface TiposDeActividad {
  id_tipo_actividad: string | null;
  nombre: string | null;
}
