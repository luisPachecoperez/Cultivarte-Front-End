export interface NombresDeActividad {
  id_tipo_actividad: string;
  nombre: string;
}
